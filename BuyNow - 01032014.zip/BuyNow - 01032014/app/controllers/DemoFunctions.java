package controllers;


import javax.jws.WebService;

@WebService
public class DemoFunctions 
{
		public double getArea(double r) 
		{
			double i=99;
			return i;
	    }
}
